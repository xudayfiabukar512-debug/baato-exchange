import React, { useState, useEffect } from "react";

const API_BASE = import.meta.env.VITE_API_URL || "/api";
const ADMIN_WHATSAPP_NUMBER = "252615999374"; // Lambarka WhatsApp-ka ee fariintu u socoto

// ── Inline SVG Icons ──
const Ic = ({ d, size = 16, color = "currentColor", stroke = 2, fill = "none" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" style={{ display: "inline-block", verticalAlign: "middle", flexShrink: 0 }}>
    {Array.isArray(d) ? d.map((p, i) => <path key={i} d={p} />) : <path d={d} />}
  </svg>
);
const ChevronLeft = ({ size = 16, color = "currentColor" }) => <Ic size={size} color={color} d="M15 18l-6-6 6-6" />;
const Hexagon = ({ size = 16, color = "currentColor", strokeWidth = 2 }) => <Ic size={size} color={color} stroke={strokeWidth} d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />;

const cs = { background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 16, padding: 16, marginBottom: 12 };
const is = { width: "100%", background: "rgba(0,0,0,0.45)", border: "1px solid rgba(255,255,255,0.15)", borderRadius: 10, padding: "12px 14px", color: "#fff", fontSize: 14, fontFamily: "monospace", outline: "none", boxSizing: "border-box", display: "block", marginBottom: 10 };
const lb = { fontSize: 10, letterSpacing: 2, color: "#aaa", marginBottom: 5, display: "block" };
const bg = (ex = {}) => ({ width: "100%", background: "linear-gradient(135deg,#00e676,#00c853)", color: "#000", border: "none", borderRadius: 12, padding: 14, fontSize: 14, fontWeight: 900, cursor: "pointer", fontFamily: "monospace", letterSpacing: 1, ...ex });

function BackBtn({ onClick }) {
  return (
    <button onClick={onClick} style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.15)", color: "#fff", borderRadius: 8, padding: "6px 12px", cursor: "pointer", fontSize: 12, fontFamily: "monospace", display: "flex", alignItems: "center", gap: 6 }}>
      <ChevronLeft size={14} /> Back
    </button>
  );
}

// ── 👁️ VIEWER – READ ONLY (MUUJINAYA FARIIMAHA & USERS) ──
function ViewerReadOnlyPage({ onBack, token }) {
  const [data, setData] = useState({ overview: {}, users: [], messages: [] });
  const [tab, setTab] = useState("messages");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  const fetchViewerData = () => {
    fetch(`${API_BASE}/viewer/overview`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    })
      .then((res) => res.json())
      .then((json) => {
        if (json.success) setData(json);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  };

  useEffect(() => {
    fetchViewerData();
    const interval = setInterval(fetchViewerData, 3000); // Cusbooneysii 3 ilbiriqsi kasta
    return () => clearInterval(interval);
  }, [token]);

  const filteredUsers = (data.users || []).filter((u) => u.email?.toLowerCase().includes(search.toLowerCase()) || u.name?.toLowerCase().includes(search.toLowerCase()) || u.mobile?.includes(search));
  const filteredMsgs = (data.messages || []).filter((m) => m.userName?.toLowerCase().includes(search.toLowerCase()) || m.currency?.toLowerCase().includes(search.toLowerCase()) || m.requestType?.toLowerCase().includes(search.toLowerCase()));

  return (
    <div style={{ padding: "14px 12px", maxWidth: 480, margin: "0 auto", fontFamily: "monospace" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
        <BackBtn onClick={onBack} />
      </div>

      <div style={{ ...cs, background: "linear-gradient(135deg,rgba(240,169,58,0.08),rgba(0,176,255,0.05))", border: "1px solid rgba(240,169,58,0.25)", textAlign: "center", padding: "16px" }}>
        <div style={{ fontSize: 10, color: "#aaa", letterSpacing: 2 }}>LIVE INCOMING REQUESTS & USERS</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginTop: 10 }}>
          <div style={{ background: "rgba(0,0,0,0.3)", padding: 8, borderRadius: 8 }}>
            <div style={{ fontSize: 9, color: "#888" }}>FARIIMAHA</div>
            <div style={{ fontSize: 14, fontWeight: 900, color: "#00e676" }}>{data.overview.totalMessages || 0}</div>
          </div>
          <div style={{ background: "rgba(0,0,0,0.3)", padding: 8, borderRadius: 8 }}>
            <div style={{ fontSize: 9, color: "#888" }}>USERS</div>
            <div style={{ fontSize: 14, fontWeight: 900, color: "#00b0ff" }}>{data.overview.totalUsers || 0}</div>
          </div>
          <div style={{ background: "rgba(0,0,0,0.3)", padding: 8, borderRadius: 8 }}>
            <div style={{ fontSize: 9, color: "#888" }}>STATUS</div>
            <div style={{ fontSize: 11, fontWeight: 900, color: "#00e676" }}>ONLINE</div>
          </div>
        </div>
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
        <button onClick={() => setTab("messages")} style={{ flex: 1, padding: 10, borderRadius: 10, border: tab === "messages" ? "1px solid #00e676" : "1px solid rgba(255,255,255,0.1)", background: tab === "messages" ? "rgba(0,230,118,0.15)" : "rgba(255,255,255,0.04)", color: tab === "messages" ? "#00e676" : "#aaa", cursor: "pointer", fontWeight: "bold", fontSize: 12 }}>
          📨 Fariimaha Codsiyada ({data.messages?.length || 0})
        </button>
        <button onClick={() => setTab("users")} style={{ flex: 1, padding: 10, borderRadius: 10, border: tab === "users" ? "1px solid #00b0ff" : "1px solid rgba(255,255,255,0.1)", background: tab === "users" ? "rgba(0,176,255,0.15)" : "rgba(255,255,255,0.04)", color: tab === "users" ? "#00b0ff" : "#aaa", cursor: "pointer", fontWeight: "bold", fontSize: 12 }}>
          👥 Users ({data.users?.length || 0})
        </button>
      </div>

      <input style={is} placeholder={`🔍 Search...`} value={search} onChange={(e) => setSearch(e.target.value)} />

      {loading ? (
        <div style={{ textAlign: "center", color: "#aaa", padding: 20 }}>Soo dejinaya xogta...</div>
      ) : tab === "messages" ? (
        <div style={cs}>
          <div style={{ fontSize: 11, color: "#888", marginBottom: 10 }}>FARIIMAHA CODSIYADA EE SOO DHACAY (READ ONLY)</div>
          {filteredMsgs.length === 0 ? (
            <div style={{ color: "#666", textAlign: "center", padding: 16 }}>Weli fariin codsi ah ma soo dhicin</div>
          ) : (
            filteredMsgs.map((m) => (
              <div key={m.id} style={{ background: "rgba(0,0,0,0.35)", border: "1px solid rgba(0,230,118,0.2)", padding: 12, borderRadius: 10, marginBottom: 10 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                  <span style={{ color: "#00e676", fontWeight: "bold", fontSize: 13 }}>{m.requestType}: ${m.amount} {m.currency}</span>
                  <span style={{ fontSize: 10, background: "rgba(240,169,58,0.2)", color: "#f0a93a", padding: "2px 6px", borderRadius: 4 }}>{m.network}</span>
                </div>
                <div style={{ fontSize: 11, color: "#fff" }}>Macmiilka: <strong>{m.userName}</strong></div>
                <div style={{ fontSize: 11, color: "#aaa" }}>Taleefan: {m.userMobile}</div>
                <div style={{ fontSize: 11, color: "#aaa" }}>Email: {m.userEmail}</div>
                <div style={{ fontSize: 10, color: "#666", marginTop: 4 }}>Waqtiga: {m.time}</div>
              </div>
            ))
          )}
        </div>
      ) : (
        <div style={cs}>
          <div style={{ fontSize: 11, color: "#888", marginBottom: 10 }}>USERS DATABASE (READ ONLY)</div>
          {filteredUsers.map((u) => (
            <div key={u.id} style={{ background: "rgba(0,0,0,0.3)", border: "1px solid rgba(255,255,255,0.08)", padding: 10, borderRadius: 8, marginBottom: 8 }}>
              <div style={{ color: "#00b0ff", fontWeight: "bold" }}>👤 {u.name}</div>
              <div style={{ fontSize: 11, color: "#aaa" }}>Email: {u.email} | Tel: {u.mobile}</div>
              <div style={{ fontSize: 10, color: "#666", marginTop: 2 }}>Diiwaangelinta: {u.registeredAt}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── BATO EXCHANGE MAIN EXCHANGE DASHBOARD ──
function ExchangeDashboard({ user, token, onLogout, onOpenViewer }) {
  const [type, setType] = useState("deposit"); // "deposit" ama "withdrawal"
  const [currency, setCurrency] = useState("USDT");
  const [network, setNetwork] = useState("TRC20");
  const [amount, setAmount] = useState("");

  const coins = [
    { coin: "USDT", net: "TRC20", color: "#00e676" },
    { coin: "USDT", net: "SOL", color: "#9945FF" },
    { coin: "USDC", net: "TRC20", color: "#00b0ff" },
    { coin: "ETH", net: "ERC20", color: "#627EEA" },
  ];

  // 1. Marka uu taabto "MESSAGES" (Toos Viewer-ka ugu dir)
  const handleSendMessage = async () => {
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) return alert("Fadlan geli amount sax ah!");

    try {
      const res = await fetch(`${API_BASE}/messages/create`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          type,
          currency,
          network,
          amount: amt,
        }),
      });

      const data = await res.json();
      if (data.success) {
        alert("✅ " + data.message);
        setAmount("");
      } else {
        alert("❌ " + data.message);
      }
    } catch {
      alert("Cillad ayaa dhacday xiriirka server-ka.");
    }
  };

  // 2. Marka uu taabto "WHATSAPP" (Toos WhatsApp u fur)
  const handleOpenWhatsApp = () => {
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) return alert("Fadlan geli amount sax ah intaadan WhatsApp aadin!");

    const text = `*BATO EXCHANGE ${type.toUpperCase()} REQUEST*\n` +
      `👤 Macmiilka: ${user?.name || "User"}\n` +
      `📞 Taleefan: ${user?.mobile || "N/A"}\n` +
      `📧 Email: ${user?.email}\n` +
      `💰 Lacagta: ${currency} (${network})\n` +
      `💵 Qadarka: $${amt}\n` +
      `📌 Codsi: Fadlan iiga fuliya codsigeyga!`;

    const url = `https://wa.me/${ADMIN_WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
    window.open(url, "_blank");
  };

  return (
    <div style={{ padding: "14px 12px", maxWidth: 460, margin: "0 auto", fontFamily: "monospace" }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <div>
          <div style={{ fontSize: 13, fontWeight: "bold", color: "#00e676" }}>● {user?.name || "Macmiil"}</div>
          <div style={{ fontSize: 10, color: "#888" }}>{user?.mobile}</div>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          <button onClick={onOpenViewer} style={{ background: "rgba(240,169,58,0.15)", border: "1px solid #f0a93a", color: "#f0a93a", borderRadius: 8, padding: "5px 10px", cursor: "pointer", fontSize: 11, fontWeight: "bold" }}>
            👁️ Viewer Portal
          </button>
          <button onClick={onLogout} style={{ background: "rgba(255,82,82,0.15)", border: "1px solid rgba(255,82,82,0.3)", color: "#ff5252", borderRadius: 8, padding: "5px 10px", cursor: "pointer", fontSize: 11 }}>
            Logout
          </button>
        </div>
      </div>

      {/* Tab: Deposit / Withdrawal */}
      <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
        <button onClick={() => setType("deposit")} style={{ flex: 1, padding: 12, borderRadius: 10, border: type === "deposit" ? "2px solid #00e676" : "1px solid #333", background: type === "deposit" ? "rgba(0,230,118,0.15)" : "rgba(255,255,255,0.03)", color: type === "deposit" ? "#00e676" : "#aaa", fontWeight: "bold", cursor: "pointer" }}>
          📥 DEPOSIT (Dhigasho)
        </button>
        <button onClick={() => setType("withdrawal")} style={{ flex: 1, padding: 12, borderRadius: 10, border: type === "withdrawal" ? "2px solid #00b0ff" : "1px solid #333", background: type === "withdrawal" ? "rgba(0,176,255,0.15)" : "rgba(255,255,255,0.03)", color: type === "withdrawal" ? "#00b0ff" : "#aaa", fontWeight: "bold", cursor: "pointer" }}>
          📤 WITHDRAWAL (La-bixid)
        </button>
      </div>

      {/* Select Coin */}
      <div style={cs}>
        <label style={lb}>DOORO LACAGTA & SHABAKADDA</label>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 12 }}>
          {coins.map((c, i) => (
            <button
              key={i}
              onClick={() => { setCurrency(c.coin); setNetwork(c.net); }}
              style={{
                padding: "12px 8px",
                borderRadius: 10,
                border: currency === c.coin && network === c.net ? `2px solid ${c.color}` : "1px solid rgba(255,255,255,0.1)",
                background: currency === c.coin && network === c.net ? `${c.color}22` : "rgba(0,0,0,0.3)",
                color: c.color,
                fontWeight: "bold",
                cursor: "pointer",
                textAlign: "center"
              }}
            >
              <div>{c.coin}</div>
              <div style={{ fontSize: 9, color: "#aaa" }}>{c.net}</div>
            </button>
          ))}
        </div>

        {/* Amount */}
        <label style={lb}>QADARKA LACAGTA ($ AMOUNT)</label>
        <input style={{ ...is, fontSize: 16, fontWeight: "bold", color: "#00e676" }} type="number" placeholder="0.00" value={amount} onChange={(e) => setAmount(e.target.value)} />

        {/* Action Buttons: MESSAGES & WHATSAPP */}
        <label style={lb}>XUL HABKA AAD CODSI U DIREYSO</label>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 6 }}>
          <button
            onClick={handleSendMessage}
            style={{
              background: "linear-gradient(135deg,#3a6df0,#7aa2ff)",
              border: "none",
              color: "#fff",
              padding: "14px 8px",
              borderRadius: 12,
              fontWeight: "900",
              fontSize: 13,
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 6
            }}
          >
            💬 Messages (Viewer)
          </button>

          <button
            onClick={handleOpenWhatsApp}
            style={{
              background: "linear-gradient(135deg,#25d366,#128c7e)",
              border: "none",
              color: "#fff",
              padding: "14px 8px",
              borderRadius: 12,
              fontWeight: "900",
              fontSize: 13,
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 6
            }}
          >
            📱 WhatsApp (Direct)
          </button>
        </div>
      </div>
    </div>
  );
}

// ── REGISTER PAGE ──
function RegisterPage({ onRegister, onBack, onOpenViewer }) {
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [conf, setConf] = useState("");
  const [err, setErr] = useState("");

  const handleSubmit = async () => {
    setErr("");
    if (!name.trim()) return setErr("Geli magacaaga");
    if (!email.includes("@")) return setErr("Geli email sax ah");
    if (pass.length < 6) return setErr("Password min 6 xaraf");
    if (pass !== conf) return setErr("Passwords-ku isma laha!");

    try {
      const res = await fetch(`${API_BASE}/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, mobile, email, password: pass }),
      });
      const data = await res.json();
      if (!data.success) return setErr(data.message);
      alert("✅ " + data.message);
      onRegister();
    } catch {
      setErr("Server-ka lama xiriiri karin.");
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: "#0a0f1e", display: "flex", alignItems: "center", justifyContent: "center", padding: 20, fontFamily: "monospace" }}>
      <div style={{ width: "100%", maxWidth: 360 }}>
        <div style={{ textAlign: "center", marginBottom: 16 }}>
          <Hexagon size={48} color="#00e676" />
          <div style={{ fontSize: 20, fontWeight: "bold", color: "#fff", marginTop: 6 }}>Register Account</div>
        </div>
        <div style={cs}>
          {err && <div style={{ color: "#ff5252", fontSize: 12, marginBottom: 10 }}>{err}</div>}
          <label style={lb}>FULL NAME</label>
          <input style={is} value={name} onChange={(e) => setName(e.target.value)} placeholder="Magaca oo buuxa" />
          <label style={lb}>MOBILE</label>
          <input style={is} value={mobile} onChange={(e) => setMobile(e.target.value)} placeholder="+252 61XXXXXXX" />
          <label style={lb}>EMAIL</label>
          <input style={is} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email@domain.com" />
          <label style={lb}>PASSWORD</label>
          <input style={is} type="password" value={pass} onChange={(e) => setPass(e.target.value)} placeholder="Min 6 characters" />
          <label style={lb}>CONFIRM PASSWORD</label>
          <input style={is} type="password" value={conf} onChange={(e) => setConf(e.target.value)} placeholder="Repeat password" />
          <button style={bg()} onClick={handleSubmit}>CREATE ACCOUNT</button>
          <button onClick={onBack} style={{ width: "100%", marginTop: 8, background: "none", border: "none", color: "#aaa", cursor: "pointer", fontSize: 11 }}>Back to Login</button>
          <button onClick={onOpenViewer} style={{ width: "100%", marginTop: 8, background: "rgba(240,169,58,0.1)", border: "1px solid #f0a93a", color: "#f0a93a", borderRadius: 8, padding: 6, fontSize: 11, cursor: "pointer" }}>👁️ Open Viewer Portal</button>
        </div>
      </div>
    </div>
  );
}

// ── LOGIN PAGE ──
function LoginScreen({ onLogin, onRegister, onOpenViewer }) {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [err, setErr] = useState("");

  const handleLogin = async () => {
    setErr("");
    try {
      const res = await fetch(`${API_BASE}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password: pass }),
      });
      const data = await res.json();
      if (!data.success) return setErr(data.message);
      localStorage.setItem("app_token", data.token);
      localStorage.setItem("app_current_user", JSON.stringify(data.user));
      onLogin(data.user, data.token);
    } catch {
      setErr("Server-ka lama xiriiri karin. Hubi node server.js!");
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: "#0a0f1e", display: "flex", alignItems: "center", justifyContent: "center", padding: 20, fontFamily: "monospace" }}>
      <div style={{ width: "100%", maxWidth: 360 }}>
        <div style={{ textAlign: "center", marginBottom: 20 }}>
          <Hexagon size={48} color="#00e676" />
          <div style={{ fontSize: 22, fontWeight: "900", color: "#00e676", marginTop: 6 }}>BATO EXCHANGE</div>
        </div>
        <div style={cs}>
          {err && <div style={{ color: "#ff5252", fontSize: 12, marginBottom: 10 }}>{err}</div>}
          <label style={lb}>EMAIL</label>
          <input style={is} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email@domain.com" />
          <label style={lb}>PASSWORD</label>
          <input style={is} type="password" value={pass} onChange={(e) => setPass(e.target.value)} placeholder="••••••••" />
          <button style={bg()} onClick={handleLogin}>LOGIN</button>
          <button onClick={onRegister} style={{ width: "100%", marginTop: 10, background: "none", border: "none", color: "#00e676", cursor: "pointer", fontSize: 12 }}>Don't have an account? Register</button>
          <button onClick={onOpenViewer} style={{ width: "100%", marginTop: 8, background: "rgba(240,169,58,0.1)", border: "1px solid #f0a93a", color: "#f0a93a", borderRadius: 8, padding: 8, fontSize: 11, cursor: "pointer" }}>👁️ Open Viewer (Read-Only Portal)</button>
        </div>
      </div>
    </div>
  );
}

// ── MAIN APP ──
export default function App() {
  const [token, setToken] = useState(() => localStorage.getItem("app_token") || "");
  const [currentUser, setCurrentUser] = useState(() => {
    const saved = localStorage.getItem("app_current_user");
    return saved ? JSON.parse(saved) : null;
  });
  const [page, setPage] = useState(() => (localStorage.getItem("app_token") ? "dashboard" : "login"));
  const [previousPage, setPreviousPage] = useState("login");

  const handleLogin = (user, jwtToken) => {
    setToken(jwtToken);
    setCurrentUser(user);
    setPage("dashboard");
  };

  const handleLogout = () => {
    if (token) {
      fetch(`${API_BASE}/auth/logout`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      }).catch(() => {});
    }
    localStorage.removeItem("app_token");
    localStorage.removeItem("app_current_user");
    setToken("");
    setCurrentUser(null);
    setPage("login");
  };

  const openViewer = () => {
    setPreviousPage(page);
    setPage("viewer");
  };

  return (
    <div style={{ minHeight: "100vh", background: "#0a0f1e", color: "#fff", fontFamily: "monospace" }}>
      {page === "login" && <LoginScreen onLogin={handleLogin} onRegister={() => setPage("register")} onOpenViewer={openViewer} />}
      {page === "register" && <RegisterPage onRegister={() => setPage("login")} onBack={() => setPage("login")} onOpenViewer={openViewer} />}
      {page === "viewer" && <ViewerReadOnlyPage token={token} onBack={() => setPage(previousPage)} />}
      {page === "dashboard" && <ExchangeDashboard user={currentUser} token={token} onLogout={handleLogout} onOpenViewer={openViewer} />}
    </div>
  );
}
