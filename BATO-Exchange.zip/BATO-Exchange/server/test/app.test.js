const test = require('node:test');
const assert = require('node:assert/strict');
const { createApp } = require('../src/app');

class MemoryStore { constructor() { this.data = { users: [], messages: [], sessions: [] }; } save() {} }

async function start() {
  const server = createApp(new MemoryStore()).listen(0);
  await new Promise((resolve) => server.once('listening', resolve));
  return { server, base: `http://127.0.0.1:${server.address().port}` };
}

test('register, login, create request, and view it', async (t) => {
  const { server, base } = await start();
  t.after(() => server.close());
  let response = await fetch(`${base}/api/auth/register`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ name: 'Test User', mobile: '0612345678', email: 'test@example.com', password: 'secret12' }) });
  assert.equal(response.status, 201);
  response = await fetch(`${base}/api/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: 'test@example.com', password: 'secret12' }) });
  const login = await response.json();
  assert.equal(login.success, true);
  response = await fetch(`${base}/api/messages/create`, { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${login.token}` }, body: JSON.stringify({ type: 'deposit', currency: 'USDT', network: 'TRC20', amount: 25 }) });
  assert.equal(response.status, 201);
  response = await fetch(`${base}/api/viewer/overview`);
  const overview = await response.json();
  assert.equal(overview.overview.totalMessages, 1);
  assert.equal(overview.messages[0].amount, 25);
});
