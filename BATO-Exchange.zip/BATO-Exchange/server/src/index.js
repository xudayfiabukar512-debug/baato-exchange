require('dotenv').config({ path: require('node:path').resolve(__dirname, '../../.env') });
const path = require('node:path');
const express = require('express');
const { JsonStore } = require('./store');
const { createApp } = require('./app');
const { hashPassword } = require('./security');

const port = Number(process.env.PORT) || 5000;
const dataFile = path.resolve(__dirname, '../data/database.json');
const store = new JsonStore(dataFile);

const adminEmail = String(process.env.ADMIN_EMAIL || 'admin@bato.local').toLowerCase();
if (!store.data.users.some((user) => user.email === adminEmail)) {
  store.data.users.push({
    id: 'admin', name: 'BATO Admin', mobile: '', email: adminEmail,
    passwordHash: hashPassword(process.env.ADMIN_PASSWORD || 'ChangeMe123!'),
    role: 'admin', createdAt: new Date().toISOString(),
  });
  store.save();
}

const app = createApp(store, { clientOrigin: process.env.CLIENT_ORIGIN });
const clientDist = path.resolve(__dirname, '../../client/dist');
app.use(express.static(clientDist));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(clientDist, 'index.html'), (error) => error && next());
});

app.listen(port, () => console.log(`BATO Exchange: http://localhost:${port}`));
