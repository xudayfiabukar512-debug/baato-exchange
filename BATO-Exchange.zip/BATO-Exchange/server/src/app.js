const express = require('express');
const crypto = require('node:crypto');
const { hashPassword, verifyPassword, createToken } = require('./security');

function publicUser(user) {
  return { id: user.id, name: user.name, mobile: user.mobile, email: user.email, role: user.role };
}

function createApp(store, options = {}) {
  const app = express();
  const clientOrigin = options.clientOrigin || 'http://localhost:5173';

  app.disable('x-powered-by');
  app.use(express.json({ limit: '32kb' }));
  app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', clientOrigin);
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    if (req.method === 'OPTIONS') return res.sendStatus(204);
    next();
  });

  function auth(req, res, next) {
    const token = req.get('authorization')?.replace(/^Bearer\s+/i, '');
    const session = store.data.sessions.find((item) => item.token === token);
    const user = session && store.data.users.find((item) => item.id === session.userId);
    if (!user) return res.status(401).json({ success: false, message: 'Fadlan mar kale login samee.' });
    req.user = user;
    next();
  }

  app.get('/api/health', (_req, res) => res.json({ success: true, status: 'ok' }));

  app.post('/api/auth/register', (req, res) => {
    const name = String(req.body.name || '').trim();
    const mobile = String(req.body.mobile || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (!name || !mobile || !/^\S+@\S+\.\S+$/.test(email) || password.length < 6) {
      return res.status(400).json({ success: false, message: 'Magaca, mobile, email sax ah, iyo password 6+ xaraf ah waa qasab.' });
    }
    if (store.data.users.some((user) => user.email === email)) {
      return res.status(409).json({ success: false, message: 'Email-kan horay ayaa loo diiwaangeliyey.' });
    }
    store.data.users.push({
      id: crypto.randomUUID(), name, mobile, email,
      passwordHash: hashPassword(password), role: 'customer', createdAt: new Date().toISOString(),
    });
    store.save();
    res.status(201).json({ success: true, message: 'Account-ka waa la sameeyey. Hadda login samee.' });
  });

  app.post('/api/auth/login', (req, res) => {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    const user = store.data.users.find((item) => item.email === email);
    if (!user || !verifyPassword(password, user.passwordHash)) {
      return res.status(401).json({ success: false, message: 'Email ama password waa khalad.' });
    }
    store.data.sessions = store.data.sessions.filter((item) => item.userId !== user.id);
    const token = createToken();
    store.data.sessions.push({ token, userId: user.id, createdAt: new Date().toISOString() });
    store.save();
    res.json({ success: true, token, user: publicUser(user) });
  });

  app.post('/api/auth/logout', auth, (req, res) => {
    store.data.sessions = store.data.sessions.filter((item) => item.userId !== req.user.id);
    store.save();
    res.json({ success: true });
  });

  app.post('/api/messages/create', auth, (req, res) => {
    const type = String(req.body.type || '');
    const currency = String(req.body.currency || '');
    const network = String(req.body.network || '');
    const amount = Number(req.body.amount);
    const allowedPairs = new Set(['USDT:TRC20', 'USDT:SOL', 'USDC:TRC20', 'ETH:ERC20']);
    if (!['deposit', 'withdrawal'].includes(type) || !allowedPairs.has(`${currency}:${network}`) || !Number.isFinite(amount) || amount <= 0) {
      return res.status(400).json({ success: false, message: 'Codsiga xogtiisu sax ma aha.' });
    }
    store.data.messages.unshift({
      id: crypto.randomUUID(), userId: req.user.id, requestType: type,
      currency, network, amount: Math.round(amount * 100) / 100,
      status: 'pending', createdAt: new Date().toISOString(),
    });
    store.save();
    res.status(201).json({ success: true, message: 'Codsigaaga waa la diiwaangeliyey.' });
  });

  app.get('/api/viewer/overview', (req, res) => {
    const token = req.get('authorization')?.replace(/^Bearer\s+/i, '');
    const session = store.data.sessions.find((item) => item.token === token);
    const viewer = session && store.data.users.find((item) => item.id === session.userId);
    const canSeePrivate = viewer?.role === 'admin';
    const users = store.data.users.map((user) => ({
      id: user.id, name: user.name,
      mobile: canSeePrivate ? user.mobile : 'Private',
      email: canSeePrivate ? user.email : `${user.email[0]}***@${user.email.split('@')[1]}`,
      registeredAt: new Date(user.createdAt).toLocaleString(),
    }));
    const messages = store.data.messages.map((message) => {
      const owner = store.data.users.find((user) => user.id === message.userId) || {};
      return {
        id: message.id, requestType: message.requestType, currency: message.currency,
        network: message.network, amount: message.amount, status: message.status,
        userName: owner.name || 'Unknown', userMobile: canSeePrivate ? owner.mobile : 'Private',
        userEmail: canSeePrivate ? owner.email : 'Private', time: new Date(message.createdAt).toLocaleString(),
      };
    });
    res.json({ success: true, overview: { totalMessages: messages.length, totalUsers: users.length }, users, messages });
  });

  app.use('/api', (_req, res) => res.status(404).json({ success: false, message: 'API endpoint lama helin.' }));
  app.use((err, _req, res, _next) => {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error ayaa dhacay.' });
  });
  return app;
}

module.exports = { createApp };
